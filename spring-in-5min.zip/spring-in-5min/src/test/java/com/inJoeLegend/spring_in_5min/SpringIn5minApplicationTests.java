package com.inJoeLegend.spring_in_5min;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringIn5minApplicationTests {

	@Test
	void contextLoads() {
	}

}
